package com.company.springboot.redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRedisExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
